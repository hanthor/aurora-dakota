use base 'app_test';
use strict;
use warnings;
use testapi;
use gnomeutils;

my $form_factor_postfix = $testapi::form_factor_postfix;

sub run {
    start_app('gnome-logs');
    assert_screen('app_gnome_logs_home'.$form_factor_postfix, 10);
    close_app;
}

1;
