[Feature]
Description=AppArmor support
